package chapter_05;

import java.util.Scanner;

/**
 * (Computer architecture: bit-level operations) A short value is stored in 16 bits.
 * Write a program that prompts the user to enter a short integer and displays the 16
 * bits for the integer. Here are sample runs:
 *
 *      Enter an integer: 5
 *      The bits are 0000000000000101
 *
 *      Enter an integer: -5
 *      The bits are 1111111111111011
 *
 * (Hint: You need to use the bitwise right shift operator (>>) and the bitwise AND
 * operator (&), which are covered in Appendix G, Bitwise Operations.)
 */
public class PE_05_44_Computer_architecture_bit_level_operations {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter an integer: ");
        short n = scanner.nextShort();
        String s = "";

        short mask = 0b1; // to extract the last bit after shifting

        for (int i = 0; i < 16; i++) {

            short bit = (short) (n & mask); // extracting last bit i.e the
            // remainder of
            // division by 2
            s = bit + s;
            n = (short) (n >> 1); // Shifting right is dividing by 2. The last
            // bit is the remainder of the next shift.

        }

        System.out.println("The bits are ");
        System.out.println(s);
    }
}
