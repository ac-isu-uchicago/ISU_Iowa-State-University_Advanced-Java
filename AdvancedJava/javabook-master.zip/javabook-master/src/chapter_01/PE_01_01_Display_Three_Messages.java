package chapter_01;

/**
 * (Display three messages) Write a program that displays Welcome to Java,
 * Welcome to Computer Science, and Programming is fun.
 */
public class PE_01_01_Display_Three_Messages {
    public static void main(String[] args) {
        System.out.println("Welcome to Java");
        System.out.println("Welcome to Computer Science");
        System.out.println("Programming is fun");
    }
}
