package chapter_01;

/**
 * (Area and perimeter of a circle) Write a program that displays the area and perimeter
 * of a circle that has a radius of 5.5 using the following formula:
 *
 *      perimeter = 2 * radius * pi
 *      area = radius * radius * pi
 */
public class PE_01_08_Area_And_Perimeter_Of_A_Circle {
    public static void main(String[] args) {
        System.out.println("perimeter = " + 2 * 5.5 * 3.14159);
        System.out.println("area = " + 5.5 * 5.5 * 3.14159);
    }
}
