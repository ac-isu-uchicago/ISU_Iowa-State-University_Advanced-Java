package chapter_01;

/**
 * (Summation of a series) Write a program that displays the result of
 *
 *      1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9.
 */
public class PE_01_06_Summation_Of_A_Series {
    public static void main(String[] args) {
        System.out.println(1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9);
    }
}
