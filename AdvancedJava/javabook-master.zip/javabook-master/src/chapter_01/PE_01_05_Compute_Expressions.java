package chapter_01;

/**
 * (Compute expressions) Write a program that displays the result of
 *
 *      (9.5 * 4.5 - 2.5 * 3) / (45.5 - 3.5)
 */
public class PE_01_05_Compute_Expressions {
    public static void main(String[] args) {
        System.out.println((9.5 * 4.5 - 2.5 * 3) / (45.5 - 3.5));
    }
}
