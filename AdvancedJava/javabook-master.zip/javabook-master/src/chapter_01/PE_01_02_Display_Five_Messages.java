package chapter_01;

/**
 * (Display five messages) Write a program that displays Welcome to Java five times.
 */
public class PE_01_02_Display_Five_Messages {
    public static void main(String[] args) {
        System.out.println("Welcome to Java");
        System.out.println("Welcome to Java");
        System.out.println("Welcome to Java");
        System.out.println("Welcome to Java");
        System.out.println("Welcome to Java");
    }
}
