### My solutions to the Introduction to Java Programming 10th edition by Y. Daniel Liang 
by [Jeff Trimmer](https://www.linkedin.com/in/jeff-trimmer-14a4a033)

I am solving these programming exercises for practice and also for the fun of it. I am adding more to this collection as I complete them. Please use these only as a reference when doing the exercises yourself. I hope these solutions can be of use to others' learning experience.

[The Book can be found here](http://www.amazon.com/Intro-Programming-Comprehensive-Version-Edition/dp/0133761312)
