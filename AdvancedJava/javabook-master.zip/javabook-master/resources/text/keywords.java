public class keyword{
    /**
     * This is a class that contains keywords like if, else, while, etc.
     */
    public static void main(String args[]){
        // The scan should not pickup boolean or null in the next line.
        System.out.println("boolean is a keyword. So is null");
        boolean isLiteral = true;
        int intnegdec = -5;
        int intposdec = 27;
        int intoct = 0377777;
        int inthex = 0xAB7;
        int intbin = 0B01001;

        double lessthanone = .5;
        double greaterthanone = 5.5;
        double another = 37d;
        float = 3.7f;
        double exp = 3.14159e0
        char charLiteral = 'c'
    }
}